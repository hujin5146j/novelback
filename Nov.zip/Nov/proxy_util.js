const axios = require("axios");
const { chromium } = require("playwright-extra");
const StealthPlugin = require("puppeteer-extra-plugin-stealth");
chromium.use(StealthPlugin());

const { getUserProxy } = require("./db/library");

const proxies = [
  "198.23.239.134:6540",
  "107.172.163.27:6543",
  "198.105.121.200:6462",
];

const pickProxy = async (userId = null) => {
  let mode = 'rotating';
  let selectedProxy = "";

  if (userId) {
    const userSettings = await getUserProxy(userId);
    if (userSettings) {
      mode = userSettings.proxy_mode || 'rotating';
      if (userSettings.proxy_url) {
        selectedProxy = userSettings.proxy_url;
      }
    }
  }

  if (!selectedProxy) {
    if (mode === 'direct') {
      selectedProxy = proxies[0];
    } else {
      selectedProxy = proxies[Math.floor(Math.random() * proxies.length)];
    }
  }

  const [host, port] = selectedProxy.replace('http://', '').split(":");
  return { host, port, full: selectedProxy.startsWith('http') ? selectedProxy : `http://${selectedProxy}`, mode };
};

const getAxiosConfig = async (url, userId = null) => {
  const proxy = await pickProxy(userId);
  const config = {
    timeout: 30000,
    proxy: {
      host: proxy.host,
      port: parseInt(proxy.port),
    },
    headers: {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
      "Accept-Language": "en-US,en;q=0.9",
      Referer: "https://freewebnovel.com/",
    },
  };

  // Only add auth if it's one of the system proxies or if env vars are present
  // For user-defined proxies, they might include auth in the URL or not need it
  if (proxies.includes(`${proxy.host}:${proxy.port}`)) {
    config.proxy.auth = {
      username: process.env.PROXY_USER,
      password: process.env.PROXY_PASS,
    };
  }

  return config;
};

const getBrowserConfig = async (userId = null) => {
  const proxy = await pickProxy(userId);
  const config = {
    launch: {
      headless: true,
      proxy: {
        server: proxy.full,
      },
      args: [
        "--no-sandbox",
        "--disable-setuid-sandbox",
        "--disable-blink-features=AutomationControlled",
      ],
    },
    context: {
      userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
      locale: "en-US",
      viewport: { width: 1366, height: 768 },
    },
  };

  if (proxies.includes(`${proxy.host}:${proxy.port}`)) {
    config.launch.proxy.username = process.env.PROXY_USER;
    config.launch.proxy.password = process.env.PROXY_PASS;
  }

  return config;
};

const checkCloudflare = (html) => {
  if (html.includes("cf-error") || html.length < 5000) {
    throw new Error("Blocked by Cloudflare");
  }
};

module.exports = { getAxiosConfig, getBrowserConfig, checkCloudflare, proxies };
